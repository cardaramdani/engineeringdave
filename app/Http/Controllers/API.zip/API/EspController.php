<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\User;

use Illuminate\Http\Request;
use App\Esp;
class Espcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
         $data = Esp::all();
         return Response()->json($data);
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
        
            }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'sensor'=>'required',
            'value1'=>'required',
            'value2'=>'required',
            'value3'=>'required', 
        ]);

        $esp=Esp::create([
            'sensor'=> $request->sensor, 
            'value1'=> $request->value1, 
            'value2'=> $request->value2, 
            'value3'=>$request->value3, 
            
        ]);    
            return Response()->json($esp);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
     
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $sensor= $request->sensor;
        $value1 = $request->value1;
        $value2 = $request->value2;
        $value3 = $request->value3;

        $esp= Esp::find($id);
        $esp->sensor= $sensor;
        $esp->value1 = $value1;
        $esp->value2 = $value2;
        $esp->value3 = $value3;
        $esp->save();
        return "data berhasip di update";
            }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Esp $esp, $id)
    { 
        $esp= Esp::find($id);
        $esp->delete();
        return "data berhasi di hapus";
            }
}
