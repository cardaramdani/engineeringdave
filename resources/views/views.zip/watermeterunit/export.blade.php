<?php
// Skrip berikut ini adalah skrip yang bertugas untuk meng-export data tadi ke excell
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename= watermeter unit.xls");
?>
<h3>Data Water Meter Unit</h3>
    <h3>Bulan : <?php echo DATE('M-Y')?></h3>
<table border="1" cellpadding="5">
  <tr>
    <th style="background-color: cyan">No</th>
    <th style="background-color: cyan">Unit</th>
    <th style="background-color: cyan">No Seri</th>
    <th style="background-color: cyan">Stand AWal</th>
    <!-- <th style="background-color: cyan">Gambar Awal</th> -->
    <th style="background-color: cyan">Stand Akhir</th>
    <!-- <th style="background-color: cyan">Gambar Akhir</th> -->
    <th style="background-color: cyan">Pemakaian</th>
    <th style="background-color: cyan">Tanggal BAST</th>
    <th style="background-color: cyan">Tanggal Catat</th>
  </tr>
  
  <?php $i = 1;?>
 
  <?php foreach($Watermeterunit as $row):?>
    
  <tr>
  <th><?=$i; ?></th>
  <th><?=$row["Unit"]; ?></th>
  <th><?=$row["NoSeri"]; ?></th>
  <th><?=$row["StandAwal"]; ?></th>
  <!-- <th><img width="50px" src="{{ url('/dataIMG_watermeterunit/'.$row->GambarAwal) }}"></th> -->
  <th><?=$row["StandAkhir"]; ?></th>
  <!-- <th><img width="50px" src="{{ url('/dataIMG_watermeterunit/'.$row->GambarAkhir) }}"></th> -->
  <th><?=$row["TotalPakai"]; ?></th>
  <th><?=$row["TanggalBAST"]; ?></th>
  <th><?=$row["created_at"]; ?></th>
  
  </tr>
    
   <?php $i++;?> 
  <?php endforeach;?>
</table>