



<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Edit Data water meter unit</title>
</head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item font-weight-bold border border-primary rounded">
        <a class="nav-link text-primary" href="{{ url('/homescreen')}}">Home</a>
      </li>
      <li class="nav-item font-weight-bold">
        <a class="nav-link " href="{{ url('/SOP')}}">Standar Oprasional Prosedur</a>
      </li>
      <li class="nav-item dropdown  font-weight-bold">
           <a class="nav-link dropdown-toggle" href="" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          LogSheet
           </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="{{ url('/genset')}}">Genset</a>
          <a class="dropdown-item" href="{{ url('/PowerHouse')}}">Power House</a>
          <a class="dropdown-item" href="{{ url('/amr')}}">AMR</a>
          <a class="dropdown-item" href="{{ url('/stp')}}">STP</a>
          <a class="dropdown-item" href="{{ url('/pdam')}}">PDAM</a>
          <a class="dropdown-item" href="{{ url('/transferpump')}}">Transfer Pump</a>
          <a class="dropdown-item" href="{{ url('/boosterpump')}}">Booster Pump</a>
          <a class="dropdown-item" href="{{ url('/sumpitpump')}}">Sumpit Pump</a>
          <a class="dropdown-item" href="{{ url('/firepump')}}">Fire Pump</a>
          <a class="dropdown-item" href="{{ url('/logbook')}}">LogBook</a>
          
          
          </div>
      </li>
      <li class="nav-item dropdown active font-weight-bold">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Utility
        <span class="sr-only">(current)</span></a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="{{ url('/watermeterunit')}}">Water Meter Unit</a>
          <a class="dropdown-item" href="{{ url('/kwhmeterunit')}}">Kwh Meter Unit</a>
          
        </div>
      </li>
      <li class="nav-item font-weight-bold">
        <a class="nav-link" href="beritaacara">Berita Acara</a>
      </li>
    </ul>
</div>
</nav>
    <h1 align="center" class="my-5">Form Edit Data water meter unit</h1>
    @if (count($errors) > 0)
    <div class="alert alert-danger">
        <strong>Ooops!</strong> Ada sesuatu yang salah pada proses upload data<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<table class="table table-bordered table-striped table-sm">
  <thead class="fixed-header thead-dark" align="center">
<tr>
    <th scope="col" align="center" >Unit</th>
    <th scope="col" align="center">No Seri</th>
    <th scope="col" align="center">Stand Awal</th>
    <th scope="col" align="center">Gambar Awal</th>
    <th scope="col" align="center">Stand Akhir</th>
    <th scope="col" align="center">Gambar Akhir</th>
    <th scope="col" align="center">Tanggal BAST</th>
</tr>
</thead>
  <form method="post" action="/watermeterunit/edit/{{$watermeterunit->id}}" enctype="multipart/form-data">
    @method('patch')
    @csrf
    <input type="hidden" id="Gambarlama1"  name="Gambarlama1" value="{{$watermeterunit->GambarAwal}}">
    <input type="hidden" id="Gambarlama2"  name="Gambarlama2" value="{{$watermeterunit->GambarAkhir}}">
    <input type="hidden" value="" id="total" name="TotalPakai">
    <input type="hidden" id="teknisi"  name="teknisi" value="{{$watermeterunit->teknisi}}">
    
    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
         <input type="number" class="form-control" value="{{$watermeterunit->Unit}}" name="Unit" required>
          </select>
        <div class="invalid-feedback">input data sesuai aktual</div>
    </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
         <input type="text" class="form-control" value="{{$watermeterunit->NoSeri}}" name="NoSeri"required>
          </select>
          <div class="invalid-feedback">input data sesuai aktual</div>
        </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
         <input type="number" class="form-control" value="{{$watermeterunit->StandAwal}}" name="StandAwal" required>
          </select>
          <div class="invalid-feedback">input data sesuai aktual</div>
        </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
      <a href="{{ url('/dataIMG_watermeterunit/'.$watermeterunit->GambarAwal) }}" title="click to ZOOM" class="MagicZoom" rel="zoom-id:zoom;opacity-reverse:true;">
        <img src="{{ url('/dataIMG_watermeterunit/'.$watermeterunit->GambarAwal) }}" style="width:50px; height:50px;"/>
      </a>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
         <input type="number" class="form-control" name="StandAkhir" value="{{$watermeterunit->StandAkhir}}" required>
          </select>
          <div class="invalid-feedback">input data sesuai aktual</div>
        </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
      <a href="{{ url('/dataIMG_watermeterunit/'.$watermeterunit->GambarAkhir) }}" title="click to ZOOM" class="MagicZoom" rel="zoom-id:zoom;opacity-reverse:true;">
        <img src="{{ url('/dataIMG_watermeterunit/'.$watermeterunit->GambarAkhir) }}" style="width:50px; height:50px;"/>
      </a>
      <div class="custom-file">
            <input type="file" class="custom-file-input" name="GambarAkhir" >
            <label class="custom-file-label @error('GambarAkhir') is-invalid @enderror" align="left" for="GambarAkhir">Upload gambar. . .</label>
            @error('GambarAkhir')
        <div class="invalid-feedback">Gagal Upload Max file 2MB</div>
        @enderror
    </div>
    </td>

      

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
            <input type="date" class="form-control" name="TanggalBAST" value="{{$watermeterunit->TanggalBAST}}">
        <div class="invalid-feedback">pilih tanggal sesuai aktual</div>
    </div>
    </td>
    <button class="btn-lg btn-primary col-md-12 fixed-bottom font-weight-bold"  type="submit">Submit form</button>
  
  </form>
  </tbody>
  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </tbody>
  
</html>