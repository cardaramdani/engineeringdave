<html>
 <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Logbook</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 </head>
 <body>
  <div class="container">    
     <br />
     <h3 align="center">Logbook</h3>
     <br />
   <div class="table-responsive">
                <form method="post" id="logbook">
                 <span id="result"></span>
                 <table class="table table-bordered table-striped" id="logbook_table">
               <thead>
                <tr>
                  <input type="hidden" name="teknisi" value="{{Auth::user()->username}}">
                  
              
                  
                    
                </tr>
                <tr>
                  <th width="35%">Shift 
                      <div class="form-group was-validated">
                  <select class="custom-select" name="shift" required>
                  <option value="">Pilih shift</option>
                  <option value="Pagi">Pagi</option>
                  <option value="Siang">Siang</option>
                  <option value="Malam">Malam</option>
                  </select>
                  
              </div>
                    </th>
                </tr>
                <tr>
                    
                    <th width="35%">Deskripsi</th>
                    <th width="30%" >Action</th>
                  </th>
                </tr>

               </thead>
               <tbody>

               </tbody>
               <tfoot>
                <tr>
                                <td  align="right">&nbsp;</td>
                                <td>
                  @csrf

                  <input type="submit" name="save" id="save" class="btn btn-primary" value="submit" />
                 </td>
                </tr>
               </tfoot>
           </table>
                </form>
   </div>
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 
 var count = 1;

 dynamic_field(count);

 function dynamic_field(number)
 {
  html = '<tr>';

        // html += '<td><input type="text" name="teknisi[]" class="form-control" value="{{Auth::user()->username }}"/></td>';
        // html += '<td><input type="text" name="shift[]" class="form-control" /></td>';
        html += '<td width="200%" height="100%"><input type="text" name="deskripsi[]" class="form-control"  /></td>';
        if(number > 1)
        {
            html += '<td><button type="button" name="remove" id="" class="btn btn-danger remove">Remove</button></td></tr>';
            $('tbody').append(html);
        }
        else
        {   
            html += '<td><button type="button" name="add" id="add" class="btn btn-success">Add</button></td></tr>';
            $('tbody').html(html);
        }
 }

 $(document).on('click', '#add', function(){
  count++;
  dynamic_field(count);
 });

 $(document).on('click', '.remove', function(){
  count--;
  $(this).closest("tr").remove();
 });

 $('#logbook').on('submit', function(event){
        event.preventDefault();
        $.ajax({
            url:logbook/add,
            method:'POST',
            data:$(this).serialize(),
            dataType:'json',
            beforeSend:function(){
                $('#save').attr('disabled','disabled');
            },
            success:function(data)
            {
                if(data.error)
                {
                    var error_html = '';
                    for(var count = 0; count < data.error.length; count++)
                    {
                        error_html += '<p>'+data.error[count]+'</p>';
                    }
                    $('#result').html('<div class="alert alert-danger">'+error_html+'</div>');
                }
                else
                {
                    dynamic_field(1);
                    $('#result').html('<div class="alert alert-success">'+data.success+'</div>');
                }
                $('#save').attr('disabled', false);
            }
        })
 });

});
</script>
















function insert(Request $request)
    {
     if($request->ajax()) {
                          $rules = array(
                           'shift'  => 'required',
                           'teknisi'  => 'required',
                           'deskripsi.*'=>'required'
                          );

      $error = Validator::make($request->all(), $rules);
          if($error->fails())
      {
           return response()->json([
            'error'  => $error->errors()->all()
           ]);
      }

      $shift = $request->shift;
      $teknisi = $request->teknisi;
      $deskripsi=$request->deskripsi;
      for($count = 0; $count < count($deskripsi); $count++)
      {
                   $data = array(
                    'deskripsi' => $deskripsi[$count],
                    'shift'=>$shift,
                    'teknisi'=>$teknisi
                   );

                   $insert_data[] = $data; 
      }

      Logbook::insert($insert_data);
      
      return response()->json([
       'success'  => 'Data Berhasil Ditambahkan!!!.'
      ]);
     }
    }