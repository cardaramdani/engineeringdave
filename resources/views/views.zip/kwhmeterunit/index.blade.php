



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Kwh Unit</title>
     
</head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item font-weight-bold border border-primary rounded">
        <a class="nav-link text-primary" href="{{ url('/homescreen')}}">Home</a>
      </li>
      <li class="nav-item font-weight-bold">
        <a class="nav-link " href="{{ url('/SOP')}}">Standar Oprasional Prosedur</a>
      </li>
      <li class="nav-item dropdown  font-weight-bold">
           <a class="nav-link dropdown-toggle" href="" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          LogSheet
           </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="{{ url('/genset')}}">Genset</a>
          <a class="dropdown-item" href="{{ url('/PowerHouse')}}">Power House</a>
          <a class="dropdown-item" href="{{ url('/amr')}}">AMR</a>
          <a class="dropdown-item" href="{{ url('/stp')}}">STP</a>
          <a class="dropdown-item" href="{{ url('/pdam')}}">PDAM</a>
          <a class="dropdown-item" href="{{ url('/transferpump')}}">Transfer Pump</a>
          <a class="dropdown-item" href="{{ url('/boosterpump')}}">Booster Pump</a>
          <a class="dropdown-item" href="{{ url('/sumpitpump')}}">Sumpit Pump</a>
          <a class="dropdown-item" href="{{ url('/firepump')}}">Fire Pump</a>
          <a class="dropdown-item" href="{{ url('/logbook')}}">LogBook</a>
          
          
          </div>
      </li>
      <li class="nav-item dropdown active font-weight-bold">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Utility
        <span class="sr-only">(current)</span></a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="{{ url('/watermeterunit')}}">Water Meter Unit</a>
          <a class="dropdown-item" href="{{ url('/kwhmeterunit')}}">Kwh Meter Unit</a>
          
        </div>
      </li>
      <li class="nav-item font-weight-bold">
        <a class="nav-link" href="beritaacara">Berita Acara</a>
      </li>
    </ul>

<form action="/kwhmeterunit/filter" method="post" class="form-inline col-6">
  @csrf
  <label for="startdate" class="font-weight-bold text-light" >Startdate</label>
    <input type="date" 
            name="startdate" id="startdate"
            class="form-control mr-sm-1 @error('startdate') is-invalid @enderror col-4.5"
            value="{{old('startdate')}}">
    @error('startdate')
        <div class="invalid-feedback">{{$message}}</div>
    @enderror
  
    <label for="todate" class="font-weight-bold text-light" >Todate</label>
    <input type="date" 
          name="todate" id="todate"
          class="form-control mr-sm-1 @error('todate') is-invalid @enderror col-4.5" 
          value="{{old('todate')}}">
    @error('todate')
    <div class="invalid-feedback">{{$message}}</div>
    @enderror
  
    <button type="submit" class="btn btn-outline-warning col-2">Filter</button>
  
</form>
  </div>
</nav>
<h1 class="my-3">sace</h1>
                                                  <h1 align="center" class="font-weight-bold ">KWH Unit</h1>
@if (count($errors) > 0)
    <div class="alert alert-danger">
        <strong>Ooops!</strong> Ada sesuatu yang salah pada proses upload data<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<button type="button" class="btn btn-outline-warning offset-md-11" data-toggle="modal" data-target="#exampleModal1" data-whatever="@mdo">Tutorial..!!
  </button>
        @if(Auth::user()->jabatan=='chief')
<button type="button" class="btn btn-outline-success col-2 offset-md-10 " data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add New Data</button>
        @endif
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New kwh Unit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body align-middle was-validated" align="center">
       <form action="/kwhmeterunit/add" method="post" class="d-inline offset-md-10" enctype="multipart/form-data">
          @csrf
                <input type="hidden" name="teknisi" value="{{Auth::user()->username}}">

        <td scope="col" align="center" class="was-validated align-middle">
            <div class="form-group">
                <label for="TanggalBAST" class="font-weight-bold">Tanggal BAST</label>
                <input type="date" class="form-control" name="TanggalBAST" required>
            <div class="invalid-feedback">pilih tanggal sesuai aktual</div>
            </div>
        </td>
          <td scope="col" align="center" class="was-validated align-middle">
            <div class="form-group" >
              <label for="Unit" class="font-weight-bold">Unit</label>
             <input type="number" class="form-control" placeholder="Unit" name="Unit"  required>
              <div class="invalid-feedback">input data sesuai aktual</div>
            </div>
        </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
          <label for="NoSeri" class="font-weight-bold">No Seri</label>
         <input type="text" class="form-control" placeholder="No Seri" name="NoSeri"required>
          <div class="invalid-feedback">input data sesuai aktual</div>
        </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
           <div class="form-group">
          <select class="custom-select" name="Daya" required>
          <option value="">Pilih Daya Terpasang....</option>
          <option value="1,3">1300Va</option>
          <option value="2,2">2200Va</option>
          <option value="3,5">3500Va</option>
          </select>
          <div class="invalid-feedback">input data sesuai aktual</div>
          </div>    
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
          <label for="StandAwal" class="font-weight-bold">Stan dAwal</label>
         <input type="number" class="form-control" placeholder="Stand Awal" name="StandAwal" required>
          <div class="invalid-feedback">input data sesuai aktual</div>
        </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="form-group">
          <label for="StandAkhir" class="font-weight-bold">Stand Akhir</label>
         <input type="number" class="form-control" placeholder="Stand Akhir" name="StandAkhir" required>
          <div class="invalid-feedback">input data sesuai aktual</div>
        </div>
    </td>

    <td scope="col" align="center" class="was-validated align-middle">
        <div class="custom-file">
            <input type="file" class="custom-file-input" name="GambarAkhir" required>
            <label class="custom-file-label mr-sm-1 @error('GambarAkhir') is-invalid @enderror" for="GambarAkhir">Upload Gambar...</label>
            @error('GambarAkhir')
                  <div class="invalid-feedback">Gagal Upload Max file 2MB</div>
            @enderror  
        </div>
    </td>

    <td>
            <input type="hidden" class="custom-file-input" value="baruBAST" name="GambarAwal" >
    </td>
    
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button class="btn-lg btn-primary col-md-12  font-weight-bold"  type="submit">Submit form</button>
        </div>
      </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tata cara tambah data pencatatan bulanan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body align-middle was-validated" align="center">
            <h5  class="font-weight-bold " align="center">Cara untuk tambah data pencatatan bulanan</h5>
            <h5  class="font-weight-bold " align="left">1. Klik navbar pojok kiri atas</h5>
            <h5  class="font-weight-bold " align="left">2. Pilih tanggal 21 bulan lalu - 20 bulan sekarang dan klik filter</h5>
            <h5  class="font-weight-bold " align="left">3. Klik tombol ADD pada unit yang akan di tambah data pencatatan bulanan</h5>
            <h5  class="font-weight-bold " align="left">4. Input data sesuai aktual dan tekan tombol submit</h5>
            <h5  class="font-weight-bold " align="left">5. Jika sudah ada keterangan berhasil, klik kembali ke halaman form pencatatan bulanan agar tidak lupa unit terahir yang di catat</h5>
            <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>
  </div>
</div>

  <table class="table table-bordered table-striped">
<thead class="fixed-header thead-dark" align="center">
  @if (session('status'))
    <div class="alert alert-success">
      {{ session('status') }}
    </div>
  @endif
<tr>
    <th scope="col" align="center" class="align-middle">No</th>
    <th scope="col" align="center" class="align-middle">Unit</th>
    <th scope="col" align="center" class="align-middle">No Seri</th>
    <th scope="col" align="center" class="align-middle">Daya (Kva)</th>
    <th scope="col" align="center" class="align-middle">Stand Awal</th>
    <th scope="col" align="center" class="align-middle">GambarAwal</th>
    <th scope="col" align="center" class="align-middle">Stand Akhir</th>
    <th scope="col" align="center" class="align-middle">GambarAkhir</th>
    <th scope="col" align="center" class="align-middle">Pemakaian</th>
    <th scope="col" align="center" class="align-middle">Tanggal Bast</th>
    <th scope="col" align="center" class="align-middle">Tanggal Catat</th>
    <th scope="col" align="center" class="align-middle">Nama Petugas</th>
        @if(Auth::user()->jabatan=='chief')
    <th scope="col" class="align-middle">ACTION</th>
        @endif
</tr>
  </thead>
  <tbody>
     @foreach ($Kwhmeterunit as $result => $kwh)
      <tr>
        
  <td align="center" class="font-weight-bold align-middle">{{$result + $Kwhmeterunit->firstitem()}}</td>
  <td align="center" class="align-middle">{{$kwh->Unit}}</td>
  <td align="center" class="align-middle">{{$kwh->NoSeri}}</td>
  <td align="center" class="align-middle">{{$kwh->Daya}}</td>
  <td align="center" class="align-middle">{{$kwh->StandAwal}}</td>
  <td align="center" class="align-middle">
      <a href="{{ url('/dataIMG_kwhmeterunit/'.$kwh->GambarAwal) }}" title="click to ZOOM" class="MagicZoom" rel="zoom-id:zoom;opacity-reverse:true;">
        <img src="{{ url('/dataIMG_kwhmeterunit/'.$kwh->GambarAwal) }}" style="width:50px; height:50px;"/>
      </a>
    
  <td align="center" class="align-middle">{{$kwh->StandAkhir}}</td>
  <td align="center" class="align-middle">
      <a href="{{ url('/dataIMG_kwhmeterunit/'.$kwh->GambarAkhir) }}" title="click to ZOOM" class="MagicZoom" rel="zoom-id:zoom;opacity-reverse:true;">
        <img src="{{ url('/dataIMG_kwhmeterunit/'.$kwh->GambarAkhir) }}" style="width:50px; height:50px;"/>
      </a>
    
  <td align="center" class="align-middle">{{$kwh->StandAkhir-$kwh->StandAwal}}</td>
  <td align="center" class="align-middle">{{$kwh->TanggalBAST}}</td>
  <td align="center" class="align-middle">{{$kwh->created_at}}</td>
  <td align="center" class="align-middle">{{$kwh->teknisi}}</td>
  @if(Auth::user()->jabatan=='chief')
  <td align="center" class="align-middle">
    
  <form action="/kwhmeterunit/edit/{{$kwh->id}}" method="post" class="d-inline ">
      <!-- @method('update') -->
      @csrf
    <button type="submit" class="btn btn-outline-success">Edit</button> 
  </form>
  <form action="/kwhmeterunit/delete/{{$kwh->id}}" method="post" class="d-inline" onclick=" return confirm ('Yakin Mau Di Delet?');">
      @method('delete')
      @csrf
    <button type="submit" class="btn btn-outline-danger">Delete</button> 
  </form>
  </td>
  @endif
      </tr>
@endforeach
{{$Kwhmeterunit->links()}}
    </tbody>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
  
</html>